//
//  iOSLib.h
//  iOSLib
//
//  Created by vagelis spirou on 6/3/24.
//

#import <Foundation/Foundation.h>

//! Project version number for iOSLib.
FOUNDATION_EXPORT double iOSLibVersionNumber;

//! Project version string for iosLib.
FOUNDATION_EXPORT const unsigned char iOSLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSLib/PublicHeader.h>


